#/bin/bash
echo "Welcome to computer science society."
# Noah Platt
#Nplatt1@student.gsu.edu
date +%F
echo */|wc
echo $PATH
echo $USER
echo $SHELL
df
echo "Could you loan me "$"25.00?"
echo "if x=2, x*x=4, x/2=1"
ls *.sh|grep c
echo "Good bye"
date +%I
